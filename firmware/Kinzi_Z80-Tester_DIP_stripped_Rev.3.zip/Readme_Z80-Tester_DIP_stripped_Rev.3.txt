-----------------------------------------------------------------
"Z80 Tester" (original design)
-----------------------------------------------------------------

Hardware - see here:
https://oshwlab.com/vitalian1980/z80-tester
Files opened in EasyEDA and exported as PDF.
No further work done by me.

Software - see here:
https://bitbucket.org/rudolff/z80-tester/src/master/
Software downloaded and tested.

Software extension to detect U880 by kinzi @ Forum64 based on
https://www.robotrontechnik.de/html/forum/thwb/showtopic.php?threadid=11288

See/use "test.z80.u880.rev3.asm" and "test.z80.u880.rev3.bin" for 
these extensions.

All rights remain by the original authors. See there.

-----------------------------------------------------------------
"Z80 Tester DIP stripped" ("improved"? design)
-----------------------------------------------------------------

Changes by kinzi@Forum64:

* 100 % THT.
* Only 56% size of the original.
* No unwanted stuff.
* ZIF socket possible.
* Cleaned up design.
* Component numbers have changed.

-----------------------------------------------------------------

Usage:
* Make sure the solder jumper on the solder side matches
  your EPROM (2764/128 or 27256/512). Default is 256/512.
  
* Plug in CPU.

* Select desired crystal (16 or 20 MHz)

* Select desired divider (1, 2, 4, 8, 6).
  (This results in 1/1.25/2/2.5/4/5/8/10/16/20 Mhz clock.)
  
* Connect 5V.

* Perhaps a push on the reset button is needed.
  (The 100 nF C in the reset circuit is rather small.)
  
* All 8 LEDs flash at least once.

* If all 8 LEDs flash a second time, this is a CMOS CPU,
  otherwise it's a NMOS one. 
  
* If all 8 LEDs flash three times, this is a NMOS
  U880 (GDR Z80 clone).
  
* If all 8 LEDs flash four times, this would be a CMOS
  Z80 CPU with the same behaviour as the U880 NMOS one.
  However, U84C00 (GDR Z80 CMOS clones) are reported just
  to blink twice, too, just like genuine Zilog ones.
  
* Watch the cool running light showing the CPU is working.

* Since the Z80 is a fully static design you can pull the
  clock jumper off and the CPU will halt. You also might
  want to put it onto another clock selector position and
  the CPU will continue its work.

Enjoy! :-)

-----------------------------------------------------------------

kinzi@Forum64
2023/05
Free for noncommercial usage. 
All rights of the layout reserved.

-----------------------------------------------------------------

